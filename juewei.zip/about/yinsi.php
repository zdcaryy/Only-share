<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">

<meta charset="UTF-8">
    <link rel="stylesheet" href="../index/head.css">
    <link rel="stylesheet" href="../index/foot.css">
    <script src="../index/js_index/aj.js"></script>
    <script src="../index/js_index/head.js"></script>

    <link href="./bootstrap/bootstrap.min.css" rel="stylesheet">
    <script src="./js/jquery.js"></script>
    <script src="./bootstrap/bootstrap.js"></script>
    <link rel="stylesheet" href="./css-we/mianze.css">
    <title>关于隐私</title>
</head>
<body>
    <?php 
        require '../index/head.php'; 
     ?>
<div class="mydiv">
    <div class="divul">
        <ul class="nav nav-pills nav-stacked">
            <li role="presentation"><a href="juewei.php">关于觉唯</a></li>
            <li role="presentation"><a href="mianze.php">免责声明</a></li>
            <li role="presentation" class="active"><a href="#">关于隐私</a></li>
            <li role="presentation"><a href="liuyan.php">留言联系</a></li>
        </ul>
    </div>
    <div class="content11">
        <div class="head11">
            <h3 class="title">关于隐私</h3>
        </div>
        <div class="arti">
            <p>1、当您在觉唯网（以下简称本站）进行注册登录、第三方绑定帐号、购买商品、发布评论时，在您的同意以及告知的前提下，我们将会保存相关的个人资料数据（如：电子邮箱、Cookie信息、第三方网站授权信息、支付授权信息以及IP地址等等）到本站；您在本站所提供的信息都是基于自愿原则，您在任何时候都可以拒绝提供这些信息。</p>
            <p>2、在未经访问者授权下，本站绝对不会将访问者的任何隐私信息透露、展示给第三方。以下情况除外：</p>
            <ul>
                <li>根据国家执法单位要求、命令向相关单位提供相关个人资料；</li>
                <li>由于访问者的个人原因导致密码泄漏或告知他人共享注册帐号时，由此导致的个人资料泄漏；</li>
                <li>由于黑客攻击、计算机病毒侵入或发作、因政府管制而造成的暂时性关闭等影响网络正常经营之不可抗力而造成的个人资料泄露、丢失、被盗用或被窜改等；</li>
            </ul>
        </div>
    </div>
</div>
<?php 
    require '../index/foot.php';
?>
</body>
</html>